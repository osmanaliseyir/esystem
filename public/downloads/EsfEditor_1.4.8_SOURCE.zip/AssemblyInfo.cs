﻿// Assembly EsfEditor, Version 1.4.3.0

[assembly: System.Reflection.AssemblyVersion("1.4.8.0")]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Reflection.AssemblyFileVersion("1.4.8.0")]
[assembly: System.Runtime.InteropServices.Guid("4e2f46e1-eb5d-49e8-a5ab-b11327d05ac9")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyCopyright("Freeware")]
[assembly: System.Reflection.AssemblyProduct("ESF Editor")]
[assembly: System.Reflection.AssemblyCompany("")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyDescription("Viewer and Editor for Empire: Total War ESF container files")]
[assembly: System.Reflection.AssemblyTitle("ESF Editor")]

