﻿namespace EsfEditor.Utils
{
    using System;

    public enum SerializationType
    {
        Binary,
        Xml
    }
}

