﻿namespace EsfEditor.Core.Enums
{
    using System;

    public enum EsfValueType : byte
    {
        Binary41 = 0x41,
        Binary42 = 0x42,
        Binary43 = 0x43,
        Binary44 = 0x44,
        Binary45 = 0x45,
        Binary46 = 0x46,
        Binary47 = 0x47,
        Binary48 = 0x48,
        Binary49 = 0x49,
        Binary4A = 0x4a,
        Binary4B = 0x4b,
        Binary4C = 0x4c,
        Binary4D = 0x4d,
        Binary4E = 0x4e,
        Binary4F = 0x4f,
        Short = 0,
        Boolean = 1,
        Int16 = 3,
        Int32 = 4,
        UInt8 = 6,
        UInt16 = 7,
        UInt32 = 8,
        UInt64 = 9,
        Float = 0X0a,
        FloatPoint = 0X0c,
        FloatPoint3D = 0x0d,
        UTF16 = 0x0e,
        Ascii = 0x0f,
        UShort = 0x10,
        PolyNode = 0x81,
        SingleNode = 0x80,
    }
}
