﻿namespace EsfEditor.Core.Enums
{
    using System;

    public enum EsfType : uint
    {
        ABCD = 0xabcd,
        ABCE = 0xabce,
        ABCF = 0xabcf,
    }
}

