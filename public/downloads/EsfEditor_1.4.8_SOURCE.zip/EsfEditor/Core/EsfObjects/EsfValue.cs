﻿namespace EsfEditor.Core.EsfObjects
{
    using EsfEditor.Core.Enums;
    using EsfEditor.Parser;
    using System;
    using System.IO;
    using System.Text;

    public class EsfValue : IEsfValue
    {
        private string desc;
        private int isDeleted;
        private int isNew;
        private uint offset;
        private object originalValue;
        private IEsfNode parent;
        private EsfParser parser;
        private EsfValueType type;
        private object value;
        private static bool ignoreNextChange = false;

        public EsfValue()
        {
            this.desc = string.Empty;
        }

        public EsfValue(EsfParser outer)
        {
            this.desc = string.Empty;
            this.parser = outer;
        }

        public EsfValue(IEsfValue esfValue, IEsfNode parent, EsfParser parser)
        {
            this.desc = string.Empty;
            this.Offset = esfValue.Offset;
            this.Type = esfValue.Type;
            this.Value = esfValue.Value;
            this.IsNew = esfValue.IsNew;
            this.IsDeleted = esfValue.IsDeleted;
            this.OriginalValue = esfValue.OriginalValue;
            this.Description = esfValue.Description;
            this.Parent = parent;
            this.Parser = parser;
        }

        public void ChangeValue(object oldValue)
        {
            if (this.originalValue == null)
            {
                this.originalValue = oldValue;
                IEsfNode parent = this.parent;
                if (parent != null)
                    parent.ContainsChanges++;
                while (parent != null)
                {
                    parent.TreeContainsChanges++;
                    parent = parent.Parent;
                }
            }
            ignoreNextChange = true;
        }

        public virtual void QuickSave()
        {
            if (this.originalValue != null)
            {
                SlowSave();
            }
        }

        public virtual void SlowSave()
        {
            this.originalValue = null;
            this.parser.writer.Write((byte) this.type);
            switch (this.type)
            {
                case EsfValueType.UShort:
                    this.parser.writer.Write((ushort)value);
                    return;

                case EsfValueType.Int16:
                    this.parser.writer.Write((short)value);
                    return;

                case EsfValueType.Short:
                    this.parser.writer.Write((short)value);
                    return;

                case EsfValueType.Boolean:
                    this.parser.writer.Write((bool)value);
                    return;

                case EsfValueType.Int32:
                    this.parser.writer.Write((int)value);
                    return;

                case EsfValueType.UInt8:
                    this.parser.writer.Write((byte)value);
                    return;

                case EsfValueType.UInt16:
                    this.parser.writer.Write((ushort)value);
                    return;

                case EsfValueType.UInt32:
                    this.parser.writer.Write((uint)value);
                    return;

                case EsfValueType.UInt64:
                    this.parser.writer.Write((ulong)value);
                    return;

                case EsfValueType.Float:
                    this.parser.writer.Write((float)value);
                    return;

                case EsfValueType.FloatPoint:
                    this.parser.writer.Write(((EsfFloatPoint)value).x);
                    this.parser.writer.Write(((EsfFloatPoint)value).y);
                    return;

                case EsfValueType.FloatPoint3D:
                    this.parser.writer.Write(((EsfFloatPoint3D)value).x);
                    this.parser.writer.Write(((EsfFloatPoint3D)value).y);
                    this.parser.writer.Write(((EsfFloatPoint3D)value).z);
                    return;

                case EsfValueType.UTF16:
                    {
                        switch (this.parser.header.magic)
                        {
                            case EsfType.ABCD:
                            case EsfType.ABCE:
                                int length = ((string)this.value).Length;
                                this.parser.writer.Write((ushort)length);
                                this.parser.writer.Write(Encoding.Unicode.GetBytes((string)value));
                                break;

                            case EsfType.ABCF:
                                this.parser.writer.Write(this.parser.FindOrAddUTF16String((string)value));
                                break;
                        }
                        return;
                    }

                case EsfValueType.Ascii:
                    {
                        switch (this.parser.header.magic)
                        {
                            case EsfType.ABCD:
                            case EsfType.ABCE:
                                int num = ((string)this.value).Length;
                                this.parser.writer.Write((ushort)num);
                                this.parser.writer.Write(Encoding.ASCII.GetBytes((string)value));
                                break;

                            case EsfType.ABCF:
                                this.parser.writer.Write(this.parser.FindOrAddASCIIString((string)value));
                                break;
                        }
                        return;
                    }

                case EsfValueType.Binary41:
                case EsfValueType.Binary42:
                case EsfValueType.Binary43:
                case EsfValueType.Binary44:
                case EsfValueType.Binary45:
                case EsfValueType.Binary46:
                case EsfValueType.Binary47:
                case EsfValueType.Binary48:
                case EsfValueType.Binary49:
                case EsfValueType.Binary4A:
                case EsfValueType.Binary4B:
                case EsfValueType.Binary4C:
                case EsfValueType.Binary4D:
                    {
                        long position = this.parser.writer.BaseStream.Position;
                        int num4 = ((byte[])this.value).Length;
                        this.parser.writer.Write((uint)((position + 4) + num4));
                        this.parser.writer.Write((byte[])this.value);
                        return;
                    }

                case EsfValueType.Binary4E:
                    {
                        long position = this.parser.writer.BaseStream.Position;
                        int size = ((string[])this.value).Length * 4;
                        this.parser.writer.Write((uint)((position + 4) + size));
                        foreach (var str in (string[])value)
                            this.parser.writer.Write(this.parser.FindOrAddUTF16String(str));
                        break;
                    }

                case EsfValueType.Binary4F:
                    {
                        long position = this.parser.writer.BaseStream.Position;
                        int size = ((string[])this.value).Length * 4;
                        this.parser.writer.Write((uint)((position + 4) + size));
                        foreach (var str in (string[])value)
                            this.parser.writer.Write(this.parser.FindOrAddASCIIString(str));
                        break;
                    }
                
                case EsfValueType.SingleNode:
                    throw new Exception("Shouldn't find a singlenode here");

                case EsfValueType.PolyNode:
                    throw new Exception("Shouldn't find a multinode here");

                default:
                    throw new Exception("Found an unexpected type");
            }
        }

        public void UndoChangeValue()
        {
            if (this.originalValue != null)
            {
                this.value = this.originalValue;
                this.originalValue = null;
                this.parent.ContainsChanges--;
                while (this.parent != null)
                {
                    this.parent.TreeContainsChanges--;
                    this.parent = this.parent.Parent;
                }
            }
        }

        public bool ValidateNewValue(string newValue)
        {
            bool flag;
            try
            {
                switch (this.type)
                {
                    case EsfValueType.Short:
                        this.value = short.Parse(newValue);
                        break;

                    case EsfValueType.Boolean:
                        this.value = bool.Parse(newValue);
                        break;

                    case EsfValueType.UShort:
                        this.value = ushort.Parse(newValue);
                        break;

                    case EsfValueType.Int16:
                        this.value = short.Parse(newValue);
                        break;

                    case EsfValueType.Int32:
                        this.value = int.Parse(newValue);
                        break;

                    case EsfValueType.UInt8:
                        this.value = byte.Parse(newValue);
                        break;

                    case EsfValueType.UInt16:
                        this.value = ushort.Parse(newValue);
                        break;

                    case EsfValueType.UInt32:
                        this.value = uint.Parse(newValue);
                        break;

                    case EsfValueType.UInt64:
                        this.value = ulong.Parse(newValue);
                        break;

                    case EsfValueType.Float:
                        this.value = float.Parse(newValue);
                        break;

                    case EsfValueType.FloatPoint:
                        this.value = EsfFloatPoint.Parse(newValue);
                        break;

                    case EsfValueType.FloatPoint3D:
                        this.value = EsfFloatPoint3D.Parse(newValue);
                        break;

                    case EsfValueType.UTF16:
                        this.value = newValue;
                        break;

                    case EsfValueType.Ascii:
                        if (Encoding.ASCII.GetString(Encoding.ASCII.GetBytes(newValue)) != newValue)
                        {
                            throw new FormatException("ASCII string can't contain extended characters");
                        }
                        this.value = newValue;
                        break;

                    case EsfValueType.Binary41:
                    case EsfValueType.Binary42:
                    case EsfValueType.Binary43:
                    case EsfValueType.Binary44:
                    case EsfValueType.Binary45:
                    case EsfValueType.Binary46:
                    case EsfValueType.Binary47:
                    case EsfValueType.Binary48:
                    case EsfValueType.Binary49:
                    case EsfValueType.Binary4A:
                    case EsfValueType.Binary4B:
                    case EsfValueType.Binary4C:
                    case EsfValueType.Binary4D:
                    case EsfValueType.Binary4E:
                    case EsfValueType.Binary4F:
                        throw new FormatException("Can't edit binary data");

                    case EsfValueType.SingleNode:
                        throw new FormatException("Can't edit nodes");

                    case EsfValueType.PolyNode:
                        throw new FormatException("Can't edit nodes");

                    default:
                        throw new Exception("Unsupported value type: " + this.type.ToString());
                }
                flag = true;
            }
            catch (ArgumentNullException)
            {
                flag = false;
            }
            catch (FormatException)
            {
                flag = false;
            }
            catch (OverflowException)
            {
                flag = false;
            }
            return flag;
        }

        public string Description
        {
            get
            {
                return this.desc;
            }
            set
            {
                this.desc = value;
            }
        }

        public bool IsBinaryType
        {
            get
            {
                switch (this.type)
                {
                    case EsfValueType.Binary41:
                    case EsfValueType.Binary42:
                    case EsfValueType.Binary43:
                    case EsfValueType.Binary44:
                    case EsfValueType.Binary45:
                    case EsfValueType.Binary46:
                    case EsfValueType.Binary47:
                    case EsfValueType.Binary48:
                    case EsfValueType.Binary49:
                    case EsfValueType.Binary4A:
                    case EsfValueType.Binary4B:
                    case EsfValueType.Binary4C:
                    case EsfValueType.Binary4D:
                    case EsfValueType.Binary4E:
                    case EsfValueType.Binary4F:
                        return true;
                }
                return false;
            }
        }

        public int IsDeleted
        {
            get
            {
                return this.isDeleted;
            }
            set
            {
                this.isDeleted = value;
            }
        }

        public int IsNew
        {
            get
            {
                return this.isNew;
            }
            set
            {
                this.isNew = value;
            }
        }

        public bool IsValueType
        {
            get
            {
                return ((this.type != EsfValueType.SingleNode) && (this.type != EsfValueType.PolyNode));
            }
        }

        public uint Offset
        {
            get
            {
                return this.offset;
            }
            set
            {
                this.offset = value;
            }
        }

        public object OriginalValue
        {
            get
            {
                return this.originalValue;
            }
            set
            {
                this.originalValue = value;
            }
        }

        public IEsfNode Parent
        {
            get
            {
                return this.parent;
            }
            set
            {
                this.parent = value;
            }
        }

        public EsfParser Parser
        {
            get
            {
                return this.parser;
            }
            set
            {
                this.parser = value;
            }
        }

        public EsfValueType Type
        {
            get
            {
                return this.type;
            }
            set
            {
                this.type = value;
            }
        }

        public object Value
        {
            get
            {
                return this.value;
            }
            set
            {
                if (!ignoreNextChange)
                {
                    this.value = value;
                    ignoreNextChange = false;
                }
            }
        }
    }
}

