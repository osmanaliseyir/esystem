﻿namespace EsfEditor.Parser
{
    using EsfEditor.Core.Enums;
    using EsfEditor.Core.EsfObjects;
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.ComponentModel;
    using System.IO;
    using System.Text;

    public class EsfParser : IDisposable
    {
        private BackgroundWorker backgroundWorker;
        private string filename;
        private FileStream fs;
        public EsfHeader header;
        public StringCollection nodeNames;
        private int percentageDone;
        public BinaryReader reader;
        public bool readOnly;
        public IEsfNode root;
        public BinaryWriter writer;
        public SortedList<uint, string> stringValuesAscii;
        public SortedList<uint, string> stringValuesUTF16;
        public uint FindOrAddASCIIString(string s)
        {
            //If string isn't in the list yet add it
            if (!stringValuesAscii.ContainsValue(s))
            {
                //generate key
                uint i = 0;
                while (stringValuesAscii.ContainsKey(i))
                    i++;
                stringValuesAscii.Add(i,s);
            }
            //Find string, return key
            foreach (var kv in stringValuesAscii)
            {
                if (kv.Value == s)
                    return kv.Key;
            }
            throw new Exception("ASCII string not found in collection");
        }

        public uint FindOrAddUTF16String(string s)
        {
            //If string isn't in the list yet add it
            if (!stringValuesUTF16.ContainsValue(s))
            {
                //generate key
                uint i = 0;
                while (stringValuesUTF16.ContainsKey(i))
                    i++;
                stringValuesUTF16.Add(i, s);
            }
            //Find string, return key
            foreach (var kv in stringValuesUTF16)
            {
                if (kv.Value == s)
                    return kv.Key;
            }
            throw new Exception("UTF16 string not found in collection");
        }

        private EsfParser()
        {
        }

        public EsfParser(string filename)
        {
            this.filename = filename;
            try
            {
                this.fs = File.Open(filename, FileMode.Open, FileAccess.ReadWrite, FileShare.Read);
                this.readOnly = false;
            }
            catch (UnauthorizedAccessException)
            {
                this.fs = File.Open(filename, FileMode.Open, FileAccess.Read, FileShare.Read);
                this.readOnly = true;
            }
            this.reader = new BinaryReader(this.fs);
            this.header = new EsfHeader();
            this.header.magic = (EsfType)this.reader.ReadUInt32();
            switch (this.header.magic)
            {
                case EsfType.ABCD:
                    break;

                case EsfType.ABCE:
                case EsfType.ABCF:
                    this.header.unknown1 = this.reader.ReadUInt32();
                    this.header.unknown2 = this.reader.ReadUInt32();
                    break;

                default:
                    throw new Exception("Unsupported ESF type");
            }
            this.header.offsetNodeNames = this.reader.ReadUInt32();
            long position = this.reader.BaseStream.Position;
            this.reader.BaseStream.Seek((long)this.header.offsetNodeNames, SeekOrigin.Begin);
            this.nodeNames = this.ParseNodeNames();
            switch (this.header.magic)
            {
                case EsfType.ABCD:
                case EsfType.ABCE:
                    break;

                case EsfType.ABCF:
                    this.header.offsetStringList = (uint)this.reader.BaseStream.Position;
                    this.stringValuesUTF16 = this.ParseStringValuesUTF16();
                    this.stringValuesAscii = this.ParseStringValuesAscii();
                    break;
            }
            this.reader.BaseStream.Seek(position, SeekOrigin.Begin);
            this.root = (IEsfNode)this.ValueParser(null);
        }

        public void Dispose()
        {
            if (this.reader != null)
            {
                this.reader.Close();
            }
            if (this.writer != null)
            {
                this.writer.Close();
            }
            if (this.fs != null)
            {
                this.fs.Close();
            }
        }

/*        public List<byte[]> GetBinaryData(IEsfNode node)
        {
            List<byte[]> list = new List<byte[]>();
            int count = 0;
            byte[] buffer = null;
            if (!node.BeenParsed)
            {
                node.Parse();
            }
            this.reader.BaseStream.Seek((long)node.Offset, SeekOrigin.Begin);
            try
            {
                if ((node.OffsetEnd - node.Offset) > 0x7fffffff)
                {
                    uint num2 = node.OffsetEnd - node.Offset;
                    while (num2 > 0)
                    {
                        if (num2 > 0x7fffffff)
                        {
                            count = 0x7fffffff;
                            num2 -= 0x7fffffff;
                        }
                        else
                        {
                            count = (int)num2;
                            num2 = 0;
                        }
                        buffer = new byte[count];
                        this.reader.BaseStream.Read(buffer, 0, count);
                        list.Add(buffer);
                    }
                    return list;
                }
                count = (int)(node.OffsetEnd - node.Offset);
                buffer = new byte[count];
                this.reader.BaseStream.Read(buffer, 0, count);
                list.Add(buffer);
            }
            catch (Exception)
            {
                throw;
            }
            return list;
        }
*/
        public ushort GetNodeNameIndex(string nodeName)
        {
            int index = this.nodeNames.IndexOf(nodeName);
            if (index == -1)
            {
                index = this.nodeNames.Add(nodeName);
            }
            return (ushort)index;
        }

        public void ParseAll()
        {
        }

        private StringCollection ParseNodeNames()
        {
            ushort num = this.reader.ReadUInt16();
            StringCollection strings = new StringCollection();
            for (ushort i = 0; i < num; i = (ushort) (i + 1))
            {
                ushort count = this.reader.ReadUInt16();
                strings.Add(Encoding.ASCII.GetString(this.reader.ReadBytes(count)));
            }
            return strings;
        }

        private SortedList<uint, string> ParseStringValuesAscii()
        {
            uint num = this.reader.ReadUInt32();
            SortedList<uint, string> strings = new SortedList<uint, string>();
            for (uint i = 0; i < num; i++)
            {
                ushort len = this.reader.ReadUInt16();
                string val = Encoding.ASCII.GetString(this.reader.ReadBytes(len));
                strings.Add(this.reader.ReadUInt32(), val);
            }
            return strings;
        }

        private SortedList<uint, string> ParseStringValuesUTF16()
        {
            uint num = this.reader.ReadUInt32();
            SortedList<uint, string> strings = new SortedList<uint, string>();
            for (uint i = 0; i < num; i++)
            {
                ushort len = this.reader.ReadUInt16();
                string val = Encoding.Unicode.GetString(this.reader.ReadBytes(len * 2));
                strings.Add(this.reader.ReadUInt32(), val);
            }
            return strings;
        }

        public void Save(BackgroundWorker bw)
        {
            this.backgroundWorker = bw;
            this.percentageDone = 0;
            if (!this.root.HasSizeChanged())
            {
                this.writer = new BinaryWriter(this.fs);
                this.root.QuickSave();
            }
            else
            {
                string tempFileName = Path.GetTempFileName();
                this.SaveAs(tempFileName, bw);
                this.reader.Close();
                File.Delete(this.filename);
                File.Move(tempFileName, this.filename);
                try
                {
                    this.fs = File.Open(this.filename, FileMode.Open, FileAccess.ReadWrite, FileShare.Read);
                    this.readOnly = false;
                }
                catch (UnauthorizedAccessException)
                {
                    this.fs = File.Open(this.filename, FileMode.Open, FileAccess.Read, FileShare.Read);
                    this.readOnly = true;
                }
                this.reader = new BinaryReader(this.fs);
            }
        }

        public void SaveAs(string newFilename, BackgroundWorker bw)
        {
            this.backgroundWorker = bw;
            this.percentageDone = 0;
            if (!this.root.HasSizeChanged())
            {
                File.Copy(this.filename, newFilename, true);
                this.fs = File.Open(newFilename, FileMode.Open, FileAccess.Write, FileShare.None);
                this.writer = new BinaryWriter(this.fs);
                this.root.QuickSave();
                //update strings list in case it has changed
                switch (this.header.magic)
                {
                    case EsfType.ABCD:
                    case EsfType.ABCE:
                        break;

                    case EsfType.ABCF:
                        this.writer.Seek((int)this.header.offsetStringList, SeekOrigin.Begin);
                        SaveStringLists();
                        this.fs.SetLength(this.writer.BaseStream.Position);
                        break;
                }

            }
            else
            {
                this.fs = File.Open(newFilename, FileMode.Create, FileAccess.Write, FileShare.None);
                this.writer = new BinaryWriter(this.fs);
                this.writer.Write((uint)this.header.magic);
                switch (this.header.magic)
                {
                    case EsfType.ABCD:
                        break;

                    case EsfType.ABCE:
                    case EsfType.ABCF:
                        this.writer.Write(this.header.unknown1);
                        this.writer.Write(this.header.unknown2);
                        break;
                }
                this.writer.BaseStream.Seek(4L, SeekOrigin.Current);
                this.root.SlowSave();
                SaveNodeNamesList();
                switch (this.header.magic)
                {
                    case EsfType.ABCD:
                    case EsfType.ABCE:
                        break;

                    case EsfType.ABCF:
                        SaveStringLists();
                        break;
                }
            }
            this.writer.Close();
        }

        private void SaveNodeNamesList()
        {
            long position = this.writer.BaseStream.Position;
            switch (this.header.magic)
            {
                case EsfType.ABCD:
                    this.writer.BaseStream.Seek(4L, SeekOrigin.Begin);
                    break;

                case EsfType.ABCE:
                case EsfType.ABCF:
                    this.writer.BaseStream.Seek(12L, SeekOrigin.Begin);
                    break;
            }
            this.writer.Write((uint)position);
            this.writer.BaseStream.Seek(position, SeekOrigin.Begin);
            this.writer.Write((ushort)this.nodeNames.Count);
            foreach (string str in this.nodeNames)
            {
                this.writer.Write((ushort)str.Length);
                this.writer.Write(Encoding.ASCII.GetBytes(str));
            }
        }
        private void SaveStringLists()
        {
            this.writer.Write(this.stringValuesUTF16.Count);
            foreach (var kv in this.stringValuesUTF16)
            {
                this.writer.Write((ushort)kv.Value.Length);
                this.writer.Write(Encoding.Unicode.GetBytes(kv.Value));
                this.writer.Write(kv.Key);
            }
            this.writer.Write(this.stringValuesAscii.Count);
            foreach (var kv in this.stringValuesAscii)
            {
                this.writer.Write((ushort)kv.Value.Length);
                this.writer.Write(Encoding.ASCII.GetBytes(kv.Value));
                this.writer.Write(kv.Key);
            }
        }

        public void SaveExport(string newFilename, IEsfNode node, BackgroundWorker bw)
        {
            this.backgroundWorker = bw;
            this.fs = File.Open(newFilename, FileMode.Create, FileAccess.Write, FileShare.None);
            this.writer = new BinaryWriter(this.fs);
            this.writer.Write((uint)this.header.magic);
            switch (this.header.magic)
            {
                case EsfType.ABCD:
                    break;

                case EsfType.ABCE:
                case EsfType.ABCF:
                    this.writer.Write(this.header.unknown1);
                    this.writer.Write(this.header.unknown2);
                    break;
            }
            this.writer.BaseStream.Seek(4L, SeekOrigin.Current);
            node.SlowSave();
            SaveNodeNamesList();
            switch (this.header.magic)
            {
                case EsfType.ABCD:
                case EsfType.ABCE:
                    break;

                case EsfType.ABCF:
                    SaveStringLists();
                    break;
            }
            this.writer.Close();
            this.fs.Close();
            this.fs = (FileStream)this.reader.BaseStream;
        }

        public void SaveUnparsedPart(uint endOffsetSource)
        {
            Stream readerStream = reader.BaseStream;
            Stream writerStream = writer.BaseStream;
            int num = (int)((readerStream.Position * 100L) / readerStream.Length);
            if (num > this.percentageDone)
            {
                this.percentageDone = num;
                if (this.backgroundWorker.WorkerReportsProgress)
                {
                    this.backgroundWorker.ReportProgress(this.percentageDone);
                }
            }
            try
            {
                while (readerStream.Position < endOffsetSource)
                {
                    long deltaPosition = writerStream.Position - readerStream.Position;
                    EsfValueType type = (EsfValueType)this.reader.ReadByte();
                    this.writer.Write((byte)type);
                    switch (type)
                    {
                        case EsfValueType.Short:
                        case EsfValueType.UInt16:
                        case EsfValueType.UShort:
                        case EsfValueType.Int16:
                            {
                                this.writer.Write(this.reader.ReadBytes(2));
                                break;
                            }
                        case EsfValueType.Boolean:
                        case EsfValueType.UInt8:
                            {
                                this.writer.Write(this.reader.ReadByte());
                                break;
                            }
                        case EsfValueType.Int32:
                        case EsfValueType.UInt32:
                        case EsfValueType.Float:
                            {
                                this.writer.Write(this.reader.ReadBytes(4));
                                break;
                            }
                        case EsfValueType.FloatPoint:
                        case EsfValueType.UInt64:
                            {
                                this.writer.Write(this.reader.ReadBytes(8));
                                break;
                            }
                        case EsfValueType.FloatPoint3D:
                            {
                                this.writer.Write(this.reader.ReadBytes(12));
                                break;
                            }
                        case EsfValueType.UTF16:
                            {
                                switch (this.header.magic)
                                {
                                    case EsfType.ABCD:
                                    case EsfType.ABCE:
                                        ushort num5 = this.reader.ReadUInt16();
                                        this.writer.Write(num5);
                                        this.writer.Write(this.reader.ReadBytes(num5 * 2));
                                        break;

                                    case EsfType.ABCF:
                                        //TODO: Verify no copy/pasted segments appear as unparsed parts, otherwise this is a bug
                                        this.writer.Write(this.reader.ReadBytes(4));
                                        break;
                                }
                                break;
                            }
                        case EsfValueType.Ascii:
                            {
                                switch (this.header.magic)
                                {
                                    case EsfType.ABCD:
                                    case EsfType.ABCE:
                                        ushort num4 = this.reader.ReadUInt16();
                                        this.writer.Write(num4);
                                        this.writer.Write(this.reader.ReadBytes(num4));
                                        break;

                                    case EsfType.ABCF:
                                        //TODO: Verify no copy/pasted segments appear as unparsed parts, otherwise this is a bug
                                        this.writer.Write(this.reader.ReadBytes(4));
                                        break;
                                }
                                break;
                            }
                        case EsfValueType.Binary41:
                        case EsfValueType.Binary42:
                        case EsfValueType.Binary43:
                        case EsfValueType.Binary44:
                        case EsfValueType.Binary45:
                        case EsfValueType.Binary46:
                        case EsfValueType.Binary47:
                        case EsfValueType.Binary48:
                        case EsfValueType.Binary49:
                        case EsfValueType.Binary4A:
                        case EsfValueType.Binary4B:
                        case EsfValueType.Binary4C:
                        case EsfValueType.Binary4D:
                        case EsfValueType.Binary4E: // no special handling, because it can't have changed
                        case EsfValueType.Binary4F: // no special handling, because it can't have changed
                            {
                                uint num3 = this.reader.ReadUInt32();
                                this.writer.Write((uint)(num3 + deltaPosition));
                                this.writer.Write(this.reader.ReadBytes((int)(num3 - readerStream.Position)));
                                break;
                            }
                        case EsfValueType.SingleNode:
                            {
                                this.writer.Write(this.reader.ReadBytes(3));
                                uint num6 = this.reader.ReadUInt32();
                                this.writer.Write((uint)(num6 + deltaPosition));
                                this.SaveUnparsedPart(num6);
                                break;
                            }
                        case EsfValueType.PolyNode:
                            {
                                this.writer.Write(this.reader.ReadBytes(3));
                                uint polyNodesEnd = this.reader.ReadUInt32();
                                this.writer.Write((uint)(polyNodesEnd + deltaPosition));
                                uint polyNodeCount = this.reader.ReadUInt32();
                                this.writer.Write(polyNodeCount);

                                uint polyNodeEnd;
                                for (int i = 0; i < polyNodeCount; i++)
                                {
                                    polyNodeEnd = this.reader.ReadUInt32();
                                    this.writer.Write((uint)(polyNodeEnd + deltaPosition));
                                    this.SaveUnparsedPart(polyNodeEnd);
                                }
                                break;
                            }
                        default:
                            throw new Exception("Encountered unknown value type at 0x" + readerStream.Position.ToString("x8"));
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public IEsfValue ValueParser(IEsfNode parent)
        {
            IEsfValue esfValue = new EsfValue(this);
            EsfValueType type = (EsfValueType)this.reader.ReadByte();
            uint num = ((uint)this.reader.BaseStream.Position) - 1;
            switch (type)
            {
                case EsfValueType.Short:
                    esfValue.Value = this.reader.ReadInt16();
                    break;

                case EsfValueType.Boolean:
                    esfValue.Value = this.reader.ReadBoolean();
                    break;

                case EsfValueType.UShort:
                    esfValue.Value = this.reader.ReadUInt16();
                    break;

                case EsfValueType.Int16:
                    esfValue.Value = this.reader.ReadInt16();
                    break;

                case EsfValueType.Int32:
                    esfValue.Value = this.reader.ReadInt32();
                    break;

                case EsfValueType.UInt8:
                    esfValue.Value = this.reader.ReadByte();
                    break;

                case EsfValueType.UInt16:
                    esfValue.Value = this.reader.ReadUInt16();
                    break;

                case EsfValueType.UInt32:
                    esfValue.Value = this.reader.ReadUInt32();
                    break;

                case EsfValueType.UInt64:
                    esfValue.Value = this.reader.ReadUInt64();
                    break;

                case EsfValueType.Float:
                    esfValue.Value = this.reader.ReadSingle();
                    break;

                case EsfValueType.FloatPoint:
                    EsfFloatPoint point = new EsfFloatPoint
                    {
                        x = this.reader.ReadSingle(),
                        y = this.reader.ReadSingle()
                    };
                    esfValue.Value = point;
                    break;

                case EsfValueType.FloatPoint3D:
                    EsfFloatPoint3D point3D = new EsfFloatPoint3D();
                    point3D.x = this.reader.ReadSingle();
                    point3D.y = this.reader.ReadSingle();
                    point3D.z = this.reader.ReadSingle();
                    esfValue.Value = point3D;
                    break;

                case EsfValueType.UTF16:
                    switch (this.header.magic)
                    {
                        case EsfType.ABCD:
                        case EsfType.ABCE:
                            ushort num4 = this.reader.ReadUInt16();
                            esfValue.Value = Encoding.Unicode.GetString(this.reader.ReadBytes(num4 * 2));
                            break;

                        case EsfType.ABCF:
                            esfValue.Value = this.stringValuesUTF16[this.reader.ReadUInt32()];
                            break;
                    }
                    break;

                case EsfValueType.Ascii:
                    switch (this.header.magic)
                    {
                        case EsfType.ABCD:
                        case EsfType.ABCE:
                            ushort count = this.reader.ReadUInt16();
                            esfValue.Value = Encoding.ASCII.GetString(this.reader.ReadBytes(count));
                            break;

                        case EsfType.ABCF:
                            esfValue.Value = this.stringValuesAscii[this.reader.ReadUInt32()];
                            break;
                    }
                    break;

                case EsfValueType.Binary41:
                case EsfValueType.Binary42:
                case EsfValueType.Binary43:
                case EsfValueType.Binary44:
                case EsfValueType.Binary45:
                case EsfValueType.Binary46:
                case EsfValueType.Binary47:
                case EsfValueType.Binary48:
                case EsfValueType.Binary49:
                case EsfValueType.Binary4A:
                case EsfValueType.Binary4B:
                case EsfValueType.Binary4C:
                case EsfValueType.Binary4D:
                    int num2 = (int)(this.reader.ReadUInt32() - ((uint)this.reader.BaseStream.Position));
                    byte[] buffer = this.reader.ReadBytes(num2);
                    esfValue.Value = buffer;
                    break;

                case EsfValueType.Binary4E:
                    {
                        int size = (int)(this.reader.ReadUInt32() - ((uint)this.reader.BaseStream.Position));
                        var strings = new string[size / 4];
                        for (int i = 0; i < size / 4; i++)
                            strings[i] = this.stringValuesUTF16[this.reader.ReadUInt32()];
                        esfValue.Value = strings;
                        break;
                    }

                case EsfValueType.Binary4F:
                    {
                        int size = (int)(this.reader.ReadUInt32() - ((uint)this.reader.BaseStream.Position));
                        var strings = new string[size / 4];
                        for (int i = 0; i < size / 4; i++)
                            strings[i] = this.stringValuesAscii[this.reader.ReadUInt32()];
                        esfValue.Value = strings;
                        break;
                    }

                case EsfValueType.SingleNode:
                    esfValue = new EsfSingleNode(this);
                    ((EsfNode)esfValue).Name = this.nodeNames[this.reader.ReadUInt16()];
                    ((EsfNode)esfValue).Version = this.reader.ReadByte();
                    this.reader.BaseStream.Seek((long)this.reader.ReadUInt32(), SeekOrigin.Begin);
                    if (parent != null)
                    {
                        esfValue.IsDeleted = parent.IsDeleted;
                        esfValue.IsNew = parent.IsNew;
                    }
                    break;

                case EsfValueType.PolyNode:
                    esfValue = new EsfPolyNode(this);
                    ((EsfNode)esfValue).Name = this.nodeNames[this.reader.ReadUInt16()];
                    ((EsfNode)esfValue).Version = this.reader.ReadByte();
                    this.reader.BaseStream.Seek((long)this.reader.ReadUInt32(), SeekOrigin.Begin);
                    if (parent != null)
                    {
                        esfValue.IsDeleted = parent.IsDeleted;
                        esfValue.IsNew = parent.IsNew;
                    }
                    break;

                default:
                    throw new Exception("Unsupported value type: " + ((byte)type).ToString() + " at: " + Convert.ToString((long)esfValue.Offset, 0x10));
            }
            esfValue.Parent = parent;
            esfValue.Offset = num;
            esfValue.Type = type;
            return esfValue;
        }
    }
}

